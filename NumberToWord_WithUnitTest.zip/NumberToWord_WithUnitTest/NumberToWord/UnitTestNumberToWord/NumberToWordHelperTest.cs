﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NumberToWord;

namespace UnitTestNumberToWord
{
    [TestClass]
    public class NumberToWordHelperTest
    {
        #region "IsNumeric"
        [TestMethod]
        public void IsNumeric_If_Input_Number_Is_Empty_Test()
        {
            var result = NumberToWordHelper.IsNumeric("");

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void IsNumeric_If_Input_Number_Is_Not_Empty_Test()
        {
            var result = NumberToWordHelper.IsNumeric("56987");

            Assert.IsTrue(result);
        }

        [TestMethod]
        public void IsNumeric_If_Input_Number_Is_Not_Empty_Returns_False_Test()
        {
            var result = NumberToWordHelper.IsNumeric("-1");

            Assert.IsFalse(result);
        }

        #endregion

        #region "NumberToWords"
        [TestMethod]
        public void NumberToWords_While_Number_Is_Zero_Test()
        {
            var result = NumberToWordHelper.NumberToWords(0);

            Assert.AreEqual("zero", result);
        }

        [TestMethod]
        public void NumberToWords_While_Number_Is_Less_Then_Zero_Test()
        {
            var result = NumberToWordHelper.NumberToWords(-1);

            Assert.AreEqual("minus one", result);
        }

        [TestMethod]
        public void NumberToWords_While_Number_Is_Greater_Then_Zero_Test()
        {
            var result = NumberToWordHelper.NumberToWords(2);

            Assert.AreEqual("two", result);
        }

        [TestMethod]
        public void NumberToWords_While_Number_Is_Greater_Then_Twenty_Test()
        {
            var result = NumberToWordHelper.NumberToWords(44);

            Assert.AreEqual("forty-four", result);
        }

        [TestMethod]
        public void NumberToWords_While_Number_Is_Two_Hundred_Test()
        {
            var result = NumberToWordHelper.NumberToWords(200);

            Assert.AreEqual("two hundred ", result);
        }

        [TestMethod]
        public void NumberToWords_While_Number_Is_Two_Thousand_Test()
        {
            var result = NumberToWordHelper.NumberToWords(2000);

            Assert.AreEqual("two thousand ", result);
        }

        [TestMethod]
        public void NumberToWords_While_Number_Is_Twenty_million_Test()
        {
            var result = NumberToWordHelper.NumberToWords(20000000);

            Assert.AreEqual("twenty million ", result);
        }

        #endregion
    }
}
