﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberToWord
{
    class Program
    {
        static void Main(string[] args)
        {
            string number = string.Empty;
                       
            Console.Write("Enter the number = ");
            number = Console.ReadLine();

            if (!string.IsNullOrWhiteSpace(number))
            {
                if (NumberToWordHelper.IsNumeric(number))
                {
                    try
                    {
                        var result = NumberToWordHelper.NumberToWords(long.Parse(number));
                        Console.WriteLine("\nNumber in words is = " + result);
                    }
                    catch(OverflowException)
                    {
                        Console.WriteLine("\nEntered value is too large.");
                    }
                }
                else
                {                    
                    Console.WriteLine("\nPlease enter positive numbers only (decimal or string values are not supported).");
                }
            }

            Console.ReadLine();
        }
    }
}
